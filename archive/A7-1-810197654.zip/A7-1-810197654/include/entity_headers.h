
#ifndef ENTITY_HEADERS_H
#define ENTITY_HEADERS_H

#include "entity.h"
#include "user.h"
#include "film.h"
#include "comment.h"
#include "notification.h"

#endif
