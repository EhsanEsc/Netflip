
#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include "entity.h"
#include <vector>

class Noti : public Entity
{
public:
  Noti(Parametrs params);
  void print();
private:
};

#endif
