
make
./Netflip.out < in.txt
read -p "*************************"
